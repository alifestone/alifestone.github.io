# Handoff: Slimo「拖曳懸空」狀態精靈（slimeDrag / drop）

## Overview
為像素史萊姆吉祥物 Slimo 新增「被滑鼠拖曳到半空中」的狀態精靈，取代平常爬行的樣子。包含：主體 drag 精靈（18×17）與分離後的小水滴精靈（4×4，滴落動畫用）。

## About the Design Files
本資料夾內容是 **設計參考**（HTML 原型中使用的像素圖字元陣列），不是可直接上線的產品程式碼。任務是把這組精靈資料整合進目標程式碼庫（`site.js` 的 `SPRITES` 物件）並沿用既有的 canvas 繪製管線。若目標環境不同（React、canvas lib 等），請以既有模式重現。

## Fidelity
**High-fidelity**。字元陣列即最終像素資料，需逐像素一致：硬邊、無抗鋸齒（canvas 需 `image-rendering: pixelated`，且 context 不做平滑）。

## Sprite Data

每格一字元，`.` 為透明。淺色 / 深色主題共用同一組字元，只換調色盤。

### slimeDrag — 18 寬 × 17 高

```js
slimeDrag: [
  '......KKKKKK......',
  '.....KDDDDDDK.....',
  '....KDBBBBBBDK....',
  '...KDBWWBBBBBDK...',
  '...KBWWWBBBBBBK...',
  '..KDBBWBBCBBBBDK..',
  '..KBBBBBBBCBBBBK..',
  '.KDBBBBBBBBBBBBDK.',
  '.KBBBEEBBBBEEBBBK.',
  '.KBBEEBBBBBBEEBBK.',
  '.KBBBBBBEBEBBBBBK.',
  'KDBBBBBBBEBBBBBBDK',
  'KBBBBBBBBBBBBBBBBK',
  'KDBBBBBBBBBBBBBBDK',
  '.KKDDBBBBBBBBDDKK.',
  '...KKKKKBBKKKKK...',
  '.......KBCK.......'
],
```

### drop — 4 寬 × 4 高（分離後的小水滴）

```js
drop: [
  '.KK.',
  'KBCK',
  'KBBK',
  '.KK.'
],
```

## Design Tokens（調色盤，與既有程式完全相同）

```js
PAL_BLUE  = { K:'#10101A', B:'#45C6F0', D:'#1E6BD6', E:'#0C2F8F', W:'#FFFFFF', C:'#CFF6FF' }; // 深色主題
PAL_CORAL = { K:'#10101A', B:'#FF8A70', D:'#E0503A', E:'#8C1F33', W:'#FFFFFF', C:'#FFD9CC' }; // 淺色主題
```

字元對應：
- `K` 描邊（#10101A）
- `D` 深色一階陰影 — 頂部被抓處與左右輪廓內緣
- `E` 最深色 — 只用在五官：下垂閉眼（外側往下斜的 ╲ ╱，第 8–9 行）與波浪小嘴（∿，第 10–11 行）
- `B` 主體色
- `W` 白色高光團（左上，位於被抓的窄頸處）
- `C` 淺色高光 — 十字閃光（第 5–6 行）＋滴液高光（第 16 行與 drop 右上角）

## 造型意圖
- **不跳動**：靜態懸空姿勢，無踏步節奏；輕微整體晃動由程式端做（例如 transform 微幅 rotate/translate），精靈本身不動。
- **流體下墜感**：上窄下寬的縱向水滴形——第 0–2 行收窄成被抓住的「頸部」，第 11–13 行撐到全寬 18 呈重力下垂圓肚。
- **向下滴水**：第 15 行底部描邊中央開口（`BB` 為黏液頸），第 16 行是半分離滴頭。做滴落動畫時可清掉第 16 行、於同座標生成獨立 `drop` 精靈往下掉（建議加速下墜 + 落地時淡出或濺開）。
- **無奈表情**：下垂閉眼 + 小波浪嘴，委屈但可愛。

## Interactions & Behavior
- 拖曳開始（pointerdown + 移動）：以 `slimeDrag` 取代爬行精靈；canvas 尺寸改為 18×17（平常為 18×12）。
- 錨點建議用 **頂部中心**（抓取點），不是底部——放開時再切回底部錨點的爬行精靈。
- 滴落循環（建議）：每 1.5–2.5s 隨機一次；隱藏第 16 行滴頭 → 生成 `drop` 從同位置下落 → 落地消失 → 滴頭重新出現。
- 放開（pointerup）：切回一般 `SLIME` 爬行精靈，可加一個短暫落地壓扁幀（既有程式若有 boing 動畫可重用）。

## 繪製方式（沿用既有 drawMap）
既有頁面的 `drawMap(canvas, rows)`：逐字元 `fillRect(x, y, 1, 1)`，canvas 實際尺寸 = 字元陣列尺寸，CSS 放大 7 倍（例：18×17 → `width:126px;height:119px`），並套 `image-rendering:pixelated`（既有 `.pxc` class）。

## Assets
- `drag-preview.png` — 兩種調色盤的渲染預覽（左 CORAL / 右 BLUE），含主體與分離水滴。

## Files
- `README.md` — 本文件
- `drag-preview.png` — 精靈渲染預覽圖
